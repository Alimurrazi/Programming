#include<stdio.h>

int ara[100];

int mergesort(int low,int mid,int high)
{
    int i,j,k,l,m,n,a,b;
    int temp[100];
    i=low;
    a=low;
    b=mid+1;
    while(a<=mid && b<=high)
    {
        if(ara[a]<=ara[b])
        {
            temp[i]=ara[a];
            a++;
        }
        else
        {
            temp[i]=ara[b];
            b++;
        }
        i++;
    }
    if(a>mid)
    {
        for(j=b; j<=high; j++)
        {
            temp[i]=ara[j];
            i++;
        }
    }
    else
    {
        for(j=a; j<=mid; j++)
        {
            temp[i]=ara[j];
            i++;
        }
    }
    for(i=low; i<=high; i++)
        ara[i]=temp[i];
}

int merge(int low,int high)
{
    int mid;
    if(low<high)
    {
        mid=(low+high)/2;
        merge(low,mid);
        merge(mid+1,high);
        mergesort(low,mid,high);
    }
}

int main()
{
    int i,j,k,l,m,n;
    scanf("%d",&n);
    for(i=0; i<n; i++)
        scanf("%d",&ara[i]);
    merge(0,n-1);
    for(i=0; i<n; i++)
        printf("%d ",ara[i]);
    printf("\n");
}
