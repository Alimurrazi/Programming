#include<stdio.h>
int main()
{
    int ara[100];
    int i,j,k,l,m,n,pivot;
    scanf("%d",&n);
    for(i=0; i<n; i++)
        scanf("%d",&ara[i]);
    for(i=1; i<n; i++)
    {
        pivot=ara[i];
        j=i-1;
        while(pivot<ara[j] && j>=0)
        {
            ara[j+1]=ara[j];
            j=j-1;
        }
        ara[j+1]=pivot;
    }
    for(i=0; i<n; i++)
        printf("%d ",ara[i]);
    printf("\n");
}
