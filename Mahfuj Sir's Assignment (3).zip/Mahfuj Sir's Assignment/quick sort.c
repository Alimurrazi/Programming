#include<stdio.h>
int ara[100];

int quicksort(int first,int last)
{
    int i,j,k,l,m,n,pivot=last,temp;
    while(first<last)
    {
        for(i=first ; i<pivot; i++)
        {
            if(ara[i]>ara[pivot])
            {
                temp=ara[i];
                ara[i]=ara[pivot];
                ara[pivot]=temp;
                break;
            }
        }
        for(j=last; j>pivot; j--)
        {
            if(ara[j]<ara[pivot])
            {
                temp=ara[j];
                ara[j]=ara[pivot];
                ara[pivot]=temp;
                break;
            }
        }
        if(i==pivot && j==pivot)
        {
            quicksort(first,pivot-1);
            quicksort(pivot+1,last);
            break;
        }
    }
    return 0;
}

int main()
{
    int i,j,k,l,m,n;
    scanf("%d",&n);
    for(i=0; i<n; i++)
        scanf("%d",&ara[i]);
    quicksort(0,n-1);
    for(i=0; i<n; i++)
        printf("%d ",ara[i]);
    printf("\n");
}
